type PaymentRequestType =
    | "applePay";

type ApplePayNetworks =
    | 'amex'
    | 'cartesBancaires'
    | 'chinaUnionPay'
    | 'discover'
    | 'eftpos'
    | 'electron'
    | 'elo'
    | 'interac'
    | 'jcb'
    | 'mada'
    | 'maestro'
    | 'masterCard'
    | 'privateLabel'
    | 'visa'
    | 'vPay';

type ApplePayMerchantCapability =
    | 'supports3DS'
    | 'supportsEMV'
    | 'supportsCredit'
    | 'supportsDebit';

type ApplePayContactField =
    | "email"
    | "name"
    | "phone"
    | "postalAddress"
    | "phoneticName";

type ApplePayLineItemTypes =
    | 'final'
    | 'pending';

type ApplePayPaymentTiming =
    | 'immediate'
    | 'recurring'
    | 'deferred';

type ApplePayRecurringPaymentDateUnits =
    | 'year'
    | 'month'
    | 'day'
    | 'hour'
    | 'minute';

type ShippingTypes =
    | 'shipping'
    | 'delivery'
    | 'storePickup'
    | 'servicePickup';

type ShippingContactEditingTypes =
    | 'enabled'
    | 'storePickup';

type ApplePayPaymentMethodType =
    | 'debit'
    | 'credit'
    | 'prepaid'
    | 'store';

type ApplePayPaymentPassActivationState =
    | 'activated'
    | 'requiresActivation'
    | 'activating'
    | 'suspended'
    | 'deactivated';

type ApplePayErrorCodes =
    | "shippingContactInvalid"
    | "billingContactInvalid"
    | "addressUnserviceable"
    | "couponCodeInvalid"
    | "couponCodeExpired"
    | "unknown";

type ApplePayContactFields =
    | "phoneNumber"
    | "emailAddress"
    | "name"
    | "phoneticName"
    | "postalAddress"
    | "addressLines"
    | "locality"
    | "subLocality"
    | "postalCode"
    | "administrativeArea"
    | "subAdministrativeArea"
    | "country"
    | "countryCode";

export class ApplePayErrorClass {
    code: ApplePayErrorCodes;
    contactField: ApplePayContactFields;
    message: string;
    constructor(code: ApplePayErrorCodes, contactField: ApplePayContactFields, message: string);
}

export type ApplePaySessionConstants = {
    STATUS_FAILURE: string;
    STATUS_INVALID_BILLING_POSTAL_ADDRESS: string;
    STATUS_INVALID_SHIPPING_CONTACT: string;
    STATUS_INVALID_SHIPPING_POSTAL_ADDRESS: string;
    STATUS_PIN_INCORRECT: string;
    STATUS_PIN_LOCKOUT: string;
    STATUS_PIN_REQUIRED: string;
    STATUS_SUCCESS: string;
};

export interface ApplePayWindowProperties extends Window {
    ApplePaySession: ApplePaySessionConstants;
    ApplePayError: ApplePayErrorClass;
    [key: string]: any;
}

export type ApplePayError =
    | {
        code: ApplePayErrorCodes;
        contactField: ApplePayContactFields;
        message: string;
    }
    | ApplePayErrorClass;

export type TecPaymentRequestError = { errorType: string; message: string } | ApplePayError;

type ApplePayShippingMethods = {
    label: string;
    detail: string;
    amount: string;
    identifier: string;
};

type ApplePayPaymentContact = {
    phoneNumber?: string;
    emailAddress?: string;
    givenName?: string;
    familyName?: string;
    phoneticGivenName?: string;
    phoneticFamilyName?: string;
    addressLines?: Array<string>;
    subLocality?: string;
    locality?: string;
    postalCode?: string;
    subAdministrativeArea?: string;
    administrativeArea?: string;
    country?: string;
    countryCode?: string;
};

interface ApplePayLineItem {
    label?: string;
    amount?: string;
    type?: ApplePayLineItemTypes;
    paymentTiming?: ApplePayPaymentTiming;
    recurringPaymentStartDate?: Date;
    recurringPaymentIntervalUnit?: ApplePayRecurringPaymentDateUnits;
    recurringPaymentIntervalCount?: number;
    recurringPaymentEndDate?: Date;
    deferredPaymentDate?: Date;
}

export type ApplePayPaymentRequest = {
    storeDisplayName: string;
    total: ApplePayLineItem;
    lineItems?: Array<ApplePayLineItem>;
    currencyCode: string;
    shippingType?: ShippingTypes[];
    shippingMethods?: Array<ApplePayShippingMethods>;
    merchantCapabilities: Array<ApplePayMerchantCapability>;
    supportedNetworks: Array<ApplePayNetworks>;
    countryCode: string;
    requiredBillingContactFields?: Array<ApplePayContactField>;
    billingContact?: ApplePayPaymentContact;
    requiredShippingContactFields?: Array<ApplePayContactField>;
    shippingContact?: ApplePayPaymentContact;
    applicationData?: string;
    supportedCountries?: Array<string>;
    supportsCouponCode?: boolean;
    couponCode?: string;
    shippingContactEditingMode?: ShippingContactEditingTypes;
    applePayVersion?: number;
    /** TEConnect-only: controls when the Apple Pay button is displayed. Not sent to Apple. */
    additionalOptions?: {
        forceButtonDisplay?: boolean;
        displayButtonWhitelist?: Array<"paymentCredentialsUnavailable" | "applePayUnsupported">;
    };
};

export type ApplePayPaymentPass = {
    primaryAccountIdentifier: string;
    primaryAccountNumberSuffix: string;
    deviceAccountIdentifier?: string;
    deviceAccountNumberSuffix?: string;
    activationState: ApplePayPaymentPassActivationState;
};

export type ApplePayPaymentMethod = {
    displayName?: string;
    network?: string;
    type: ApplePayPaymentMethodType;
    paymentPass?: ApplePayPaymentPass;
};

export type ApplePayPaymentMethodUpdate = {
    newTotal: ApplePayLineItem;
    newLineItems: Array<ApplePayLineItem> | null;
};

export type ApplePayCancelSession = { sessionError: { code: string; info: any } };

type ApplePayDateComponents = {
    years?: number;
    months?: number;
    days?: number;
    hours?: number;
};

type ApplePayDateComponentsRange = {
    startDateComponents: ApplePayDateComponents;
    endDateComponents: ApplePayDateComponents;
};

type ApplePayShippingMethod = ApplePayShippingMethods & {
    dateComponentsRange?: ApplePayDateComponentsRange;
};

type ApplePayShippingMethodUpdate = {
    newTotal: ApplePayLineItem;
    newLineItems?: Array<ApplePayLineItem>;
};

type ApplePayShippingContactUpdate = {
    newTotal: ApplePayLineItem;
    newLineItems?: Array<ApplePayLineItem>;
    errors?: Array<TecPaymentRequestError>;
    newShippingMethods?: Array<ApplePayShippingMethod>;
};

type TecPaymentRequestTokenDetails = {
    type?: PaymentRequestType;
    token?: any;
    error?: string;
    additionalData?: any;
};

type GoogleIsReadyToPayResponse = {
    result: boolean;
    paymentMethodPresent?: boolean;
};

/** `paymentCredentialStatus` from Apple's `applePayCapabilities()`. */
type ApplePayPaymentCredentialStatus =
    | "paymentCredentialsAvailable"
    | "paymentCredentialStatusUnknown"
    | "paymentCredentialsUnavailable"
    | "applePayUnsupported";

type CanMakePaymentsResult = {
    applePay: boolean;
    /** Present when the browser supports `applePayCapabilities()`. */
    applePaymentCredentialStatus?: ApplePayPaymentCredentialStatus;
    googlePay?: boolean | GoogleIsReadyToPayResponse;
} | null;

type ApplePayPaymentAuthorizationResult = {
    status: number;
    errors?: Array<TecPaymentRequestError>;
};

type CompletePaymentResult = string | ApplePayPaymentAuthorizationResult;

type CompleteShippingMethodSelection = (shippingMethodUpdate: ApplePayShippingMethodUpdate) => void;
type CompletePaymentMethodSelection = (paymentMethodUpdate: ApplePayPaymentMethodUpdate) => void;
type CompleteShippingContactSelection = (shippingContactUpdate: ApplePayShippingContactUpdate) => void;
type CompletePayment = (paymentStatus: CompletePaymentResult) => void;

type ConfirmTokenListener = (args: { tokenDetails: TecPaymentRequestTokenDetails; completePayment: CompletePayment }) => any;
type PaymentMethodListener = (args: { paymentMethod: ApplePayPaymentMethod; completePaymentMethodSelection: CompletePaymentMethodSelection }) => any;
type ShippingMethodListener = (args: { shippingMethod: ApplePayShippingMethod; completeShippingMethodSelection: CompleteShippingMethodSelection }) => any;
type ShippingContactListener = (args: { shippingContact: ApplePayPaymentContact; completeShippingContactSelection: CompleteShippingContactSelection }) => any;
type CancelListener = (args: { sessionError: ApplePayCancelSession }) => any;

type ListenFor = (
    eventType: string,
    listener: ConfirmTokenListener | CancelListener | ShippingMethodListener | PaymentMethodListener | ShippingContactListener
) => void;

export interface TecPaymentRequestInterface {
    createPaymentRequestToken: (instanceDetails: any) => any;
    canMakePayments: () => Promise<CanMakePaymentsResult>;
    listenFor: ListenFor;
    updatePaymentRequest: (paymentRequestObject: TecPaymentRequestObject) => void;
}

/**
 * Returned by `useTecPaymentsRequest()`. Call it with a payment request object
 * to obtain a `TecPaymentRequestInterface`.
 */
export type CreateTecPaymentRequestInterface = (paymentRequestObject: TecPaymentRequestObject) => TecPaymentRequestInterface;

export type DisplayItems = {
    label: string;
    type: "LINE_ITEM" | "SUBTOTAL" | "TAX";
    price: string;
    status?: "FINAL" | "PENDING";
};

export type TransactionInfo = {
    currencyCode: string;
    countryCode?: string;
    transactionId?: string;
    totalPriceStatus: string;
    totalPrice: string;
    displayItems?: DisplayItems[];
    totalPriceLabel?: string;
    checkoutOption?: "DEFAULT" | "COMPLETE_IMMEDIATE_PURCHASE";
};

export type OfferData = { redemptionCodes: string[] };

export type IntermediateAddress = {
    administrativeArea: string;
    countryCode: string;
    locality: string;
    postalCode: string;
};

export type SelectionOptionData = { id: string };

export type IntermediatePaymentData = {
    callbackTrigger?: string;
    offerData?: OfferData;
    shippingAddress?: IntermediateAddress;
    shippingOptionData?: SelectionOptionData;
};

export type OfferDetail = { redemptionCode: string; description: string };
export type OfferInfo = { offers?: OfferDetail[] };

export type SelectionOption = { id: string; label: string; description?: string };

export type ShippingOptionParameters = {
    shippingOptions: SelectionOption[];
    defaultSelectedOptionId?: string;
};

export type PaymentDataError = { reason: string; message: string; intent: string };

export type PaymentDataRequestUpdate = {
    newOfferInfo?: OfferInfo;
    newTransactionInfo?: TransactionInfo;
    newShippingOptionParameters?: ShippingOptionParameters;
    error?: PaymentDataError;
    id?: string;
};

export type ShippingAddressParameters = {
    allowedCountryCodes?: string[];
    phoneNumberRequired?: boolean;
};

export type PaymentDataCallbacks = {
    onPaymentAuthorized?: any;
    onPaymentDataChanged?: any;
};

export type BillingAddressParameters = {
    format?: "MIN" | "FULL";
    phoneNumberRequired?: boolean;
};

export type AllowedPaymentMethodParameters = {
    allowedAuthMethods?: string[];
    allowedCardNetworks?: string[];
    allowPrepaidCards?: boolean;
    allowCreditCards?: boolean;
    assuranceDetailsRequired?: boolean;
    billingAddressRequired?: boolean;
    billingAddressParameters?: BillingAddressParameters;
};

export type AllowedPaymentMethods = {
    type: "CARD";
    parameters: AllowedPaymentMethodParameters;
};

export type GoogleAddress = {
    name?: string;
    postalCode?: string;
    countryCode?: string;
    phoneNumber?: string;
    address1?: string;
    address2?: string;
    address3?: string;
    locality?: string;
    administrativeArea?: string;
    sortingCode?: string;
};

export type CardInfoObject = {
    cardDetails: string;
    assuranceDetails: { accountVerified: boolean; cardHolderAuthenticated: boolean };
    cardNetwork: string;
    billingAddress?: GoogleAddress;
};

export type PaymentMethodTokenizationData = { type: string; token?: string };

export type PaymentMethodData = {
    type: string;
    description: string;
    info: CardInfoObject;
    tokenizationData: PaymentMethodTokenizationData;
};

export type GoogleProcessPaymentData = {
    apiVersion: number;
    apiVersionMinor: number;
    paymentMethodData: PaymentMethodData;
    email?: string;
    shippingAddress?: GoogleAddress;
};

export type GooglePaymentRequest = {
    apiVersion?: number;
    apiVersionMinor?: number;
    allowedAuthMethods?: string[];
    allowedCardNetworks: string[];
    merchantName: string;
    gatewayId: string;
    transactionInfo: TransactionInfo;
    callbackIntents?: string[];
    emailRequired?: boolean;
    shippingAddressRequired?: boolean;
    shippingOptionRequired?: boolean;
    shippingAddressParameters?: ShippingAddressParameters;
    shippingOptionParameters?: ShippingOptionParameters;
    paymentDataCallbacks?: PaymentDataCallbacks;
    existingPaymentMethodRequired?: boolean;
    allowedPaymentMethods?: AllowedPaymentMethods[];
    environment?: "TEST" | "PRODUCTION";
    allowPrepaidCards?: boolean;
    allowCreditCards?: boolean;
    assuranceDetailsRequired?: boolean;
    billingAddressRequired?: boolean;
    billingAddressParameters?: BillingAddressParameters;
    prefetchPaymentData?: boolean;
};

export type TecPaymentRequestObject =
    | { applePay?: ApplePayPaymentRequest; googlePay?: GooglePaymentRequest }
    | ApplePayPaymentRequest
    | GooglePaymentRequest;

export type GooglePayButtonTypes = "book" | "buy" | "checkout" | "donate" | "order" | "pay" | "plain" | "subscribe";

export type GooglePayButtonOptions = {
    preClick?: any;
    buttonColor?: "default" | "black" | "white";
    buttonType?: GooglePayButtonTypes;
    buttonLocale?: string;
    buttonSizeMode?: "static" | "fill";
    buttonRootNode?: Document | ShadowRoot;
    buttonRadius?: number;
};

export type ApplePayButtonOptions = {
    buttonLanguage?: string;
    buttonType?: string;
    buttonStyle?: string;
    buttonWidth?: string;
    buttonHeight?: string;
    buttonPadding?: string;
    buttonBorderRadius?: string;
    buttonBoxSizing?: string;
};

export type TecPaymentRequestOptions = {
    applePayOptions?: ApplePayButtonOptions;
    googlePayOptions?: GooglePayButtonOptions;
};

export type TecPaymentRequestProps = {
    paymentRequestInterface: TecPaymentRequestInterface;
    tecPrOptions?: TecPaymentRequestOptions;
};

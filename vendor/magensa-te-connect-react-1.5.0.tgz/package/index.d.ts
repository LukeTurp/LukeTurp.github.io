import { ReactNode } from 'react';
import {
    TecPaymentRequestObject,
    TecPaymentRequestInterface,
    TecPaymentRequestProps,
    CreateTecPaymentRequestInterface
} from './te-connect-payment-requests';

export type RequestClient = {
    instanceId: string;
    requestOrigin: string;
    pubKey: string;
};

export type TEConnectInstance = {
    requestClient: RequestClient;
    frameUrl: string;
};

export interface TEConnectProps {
    teConnect: TEConnectInstance;
    children?: ReactNode;
}

export type TEConnectChildContext = TEConnectInstance & {
    frameRef?: import('react').Ref<HTMLIFrameElement>;
    prFrameRef?: import('react').Ref<HTMLIFrameElement>;
};

export type CurrentElements = {
    elements: HTMLIFrameElement | null;
    formId: string | undefined;
};

export type CardMetaData = {
    billingZip?: string;
    expirationDate?: string;
    maskedPAN?: string;
};

export type ThreeDsStatusResp = "Y" | "A" | "N" | "U" | "C" | "R";

export type ThreeDsResults = {
    scaRequired?: boolean;
    creq?: string;
    status?: ThreeDsStatusResp;
    authenticationValue?: string;
    authenticationType?: string;
    eci?: string;
    acsUrl?: string;
    dsTransId?: string;
    acsTransId?: string;
    sdkTransId?: string;
    error?: string;
    errorDetail?: string;
    errorCode?: string;
    cardholderInfo?: string;
    transactionId?: string;
    correlationId?: string;
    code?: number;
};

export type CreatePaymentResponse = {
    magTranID?: string;
    timestamp?: string;
    customerTranRef?: string;
    token?: string | null;
    code?: string;
    message?: string;
    status?: number;
    cardMetaData?: null | CardMetaData;
    error?: string;
    threedsResults?: ThreeDsResults;
};

export interface TEConnectInterface {
    createPayment(elements: CurrentElements, billingZip?: string): Promise<CreatePaymentResponse>;
    getCurrentElements(): CurrentElements;
}

export type FlexDirection = "row" | "row-reverse" | "column" | "column-reverse";
export type FlexWrap = "wrap" | "nowrap" | "wrap-reverse" | "no-wrap";
export type InputTypes = "outlined" | "filled" | "standard";
export type InputMargins = "dense" | "none" | "normal";

/**
 * Style options for the manual entry form.
 * See: https://github.com/Magensa/te-connect-react?tab=readme-ov-file#styles-api
 */
export type StylesConfig = {
    /** General styles applied to the container. */
    base?: {
        wrapper?: {
            margin?: string | number;
            padding?: string | number;
            direction?: FlexDirection;
            flexWrap?: FlexWrap;
        };
        variants?: {
            inputType?: InputTypes;
            inputMargin?: InputMargins;
            inputSize?: "medium" | "small";
            /** When `true`, maintains a static margin on each input that does not grow with validation errors. */
            autoMinHeight?: boolean;
            /** Styles API v2 (`boxes.version: 2`). Adds card, clear-input and validation icons. */
            enableIcons?: boolean;
            /** Styles API v2 (`boxes.version: 2`). Places the CVV and EXP boxes on the same row. */
            alternateLayout?: boolean;
        };
        backgroundColor?: string;
    };
    /** Styles applied to the input elements. */
    boxes?: {
        /** Styles API version. Defaults to `1`; `2` enables the v2-only properties. */
        version?: 1 | 2;
        labelColor?: string;
        inputColor?: string;
        textColor?: string;
        borderRadius?: number;
        errorColor?: string;
        /** Styles API v2. Outline/underline width. */
        borderWidth?: number;
        /** Styles API v2. Label and outline/underline color while focused. Defaults to `labelColor`. */
        focusedColor?: string;
    };
};

export type OneOrTwo = "01" | "02";
export type OneThroughFour = "01" | "02" | "03" | "04";
export type OneThroughFive = "01" | "02" | "03" | "04" | "05";
export type AuthenticationIndicator = "01" | "02" | "03" | "04" | "05" | "06";
export type ThreeDsChallengeIndicator = "01" | "02" | "03" | "04" | "05" | "06" | "07" | "08" | "09";

export type ThreeDsAddress = {
    line1?: string;
    line2?: string;
    line3?: string;
    postCode?: string;
    city?: string;
    state?: string;
    country?: string;
};

export type ThreeDsMerchantRiskIndicator = {
    shipIndicator?: "01" | "02" | "03" | "04" | "05" | "06" | "07";
    deliveryTimeFrame?: OneThroughFour;
    reorderItemsInd?: OneOrTwo;
};

export type ThreeDsAccountInfo = {
    chAccAgeInd?: OneThroughFive;
    chAccDate?: string;
    chAccChangeInd?: OneThroughFour;
    chAccChange?: string;
    chAccPwChangeInd?: OneThroughFive;
    chAccPwChange?: string;
    shipAddressUsageInd?: string;
    txnActivityDay?: string;
    txnActivityYear?: string;
    provisionAttemptsDay?: string;
    nbPurchaseAccount?: string;
    suspiciousAccActivity?: OneOrTwo;
    shipNameIndicator?: string;
    paymentAccInd?: string;
    paymentAccAge?: string;
};

export type ThreeDsMsgExt = {
    criticalityIndicator?: boolean;
    data?: any;
    id?: string;
    name: string;
};

/**
 * Configure a 3DS session.
 * TEConnect handles `pan`, `month`, `year`, and `browser` automatically.
 * All other options are forwarded to the 3DS `authenticate-browser` request.
 * See: https://docs.3dsintegrator.com/reference/post_v2-2-authenticate-browser
 */
export type ThreeDsConfigObj = {
    /** ID of a DOM node where TEConnect will mount the challenge iframe, if required. */
    challengeNodeId: string;
    amount: number;
    messageCategory?: OneOrTwo;
    challengeIndicator?: ThreeDsChallengeIndicator;
    challengeWindowSize?: OneThroughFive;
    transactionForcedTimeout?: string;
    authenticationInd?: AuthenticationIndicator;
    recurringExpiry?: string;
    recurringFrequency?: string;
    clientTransactionId?: string;
    protocolVersion?: string;
    currency?: string;
    currencyExponent?: number;
    shipping?: ThreeDsAddress;
    billing?: ThreeDsAddress;
    email?: string;
    cardHolderName?: string;
    merchantRiskIndicator?: ThreeDsMerchantRiskIndicator;
    acctInfo?: ThreeDsAccountInfo;
    messageExtension?: ThreeDsMsgExt;
    transType?: "01" | "03" | "10" | "11" | "28";
    threeDSRequestorURL?: string;
    threeDSRequestorDecMaxTime?: string;
    threeDSRequestorDecReqInd?: "Y" | "N";
    purchaseInstalData?: string;
    addrMatch?: string;
    /** @deprecated */
    exponent?: number;
};

export type ThreeDsMethodNames = "GENERATE_JWT" | "AUTHENTICATE_BROWSER" | "FINGERPRINT_DEVICE" | "CHALLENGE";
export type ThreeDsStatus = "REQUESTED" | "SUCCESS" | "FAIL" | "AWAIT_RESULTS";

export type TecThreeDsStatus = {
    threedsMethod: ThreeDsMethodNames;
    status: ThreeDsStatus;
    message: string;
};

export type ThreeDsStatusListener = (event: TecThreeDsStatus) => void;

export interface ThreeDsInterface {
    listenFor: (eventType: string, listener: ThreeDsStatusListener) => void;
    updateThreedsConfig: (threeDsConfigObj: ThreeDsConfigObj) => void;
}

export type ThreeDsMethods = {
    createPayment(elements: CurrentElements, billingZip?: string): Promise<CreatePaymentResponse>;
    getCurrentElements(): CurrentElements;
    threeDsInterface?: ThreeDsInterface;
};

export function TEConnect(props: TEConnectProps): JSX.Element;
export function CardEntry(props: { stylesConfig?: StylesConfig }): JSX.Element;
export function useTeConnect(): TEConnectInterface;
export function useTecPaymentsRequest(): CreateTecPaymentRequestInterface | undefined;
export function TecPaymentRequestButtons(props: TecPaymentRequestProps): JSX.Element;
export function useTecThreeds(): ThreeDsMethods;
export function ThreeDsCardEntry(props: { stylesConfig?: StylesConfig; threeDsConfig: ThreeDsConfigObj }): JSX.Element;

export * from './te-connect-payment-requests';

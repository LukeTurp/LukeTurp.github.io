import { createContext as e, useCallback as t, useContext as n, useEffect as r, useRef as i, useState as a } from "react";
import { Fragment as o, jsx as s, jsxs as c } from "react/jsx-runtime";
var l = "https://svc4.magensa.net/TEConnect", u = [
	"instanceId",
	"pubKey",
	"requestOrigin"
], d = "TEConnect was called without a 'teConnect' instance. Please provide a 'teConnect' instance.", f = "'teConnect' instance provided is either incomplete, or modified. Please try again.", p = "__te-connect-secure-window", m = "TEConnect Secure Frame", h = "__teConnectSecureFrame", g = "client_style_sheet", _ = "te-connect-apple-pay-btn", v = "_tec-payment-evt-ele", y = "te-connect-google-pay-btn", b = "te-connect-apple-pay-wrapper", x = "te-connect-google-pay-wrapper", S = { passive: !0 }, C = {
	border: "none",
	margin: "0px",
	padding: "0px",
	width: "1px",
	minWidth: "100%",
	overflow: "hidden",
	display: "block",
	userSelect: "none",
	transform: "translateZ(0px)",
	height: "100%",
	minHeight: "100px"
}, w = [
	"createPaymentRequestToken",
	"canMakePayments",
	"listenFor",
	"updatePaymentRequest"
], T = {
	buttonLanguage: "en",
	buttonType: "plain",
	buttonStyle: "black",
	buttonWidth: "100%",
	buttonHeight: "30px",
	buttonPadding: "0px",
	buttonBorderRadius: "4px",
	buttonBoxSizing: "border-box"
}, E = "to the 'TecPaymentRequestButtons' component", D = "TEConnect Payment Request Interface", O = `Please provide an instance of ${D} ${E}`, k = `Create an instance of ${D} to supply ${E}`, A = `${D} was not in a recognized format.`, j = (e) => {
	if (!e) throw Error(d);
	if (typeof e.requestClient != "object") throw Error(f);
	let { requestClient: t } = e;
	for (let e of u) if (!Object.hasOwn(t, e)) throw Error(f);
	return e;
}, M = (e) => {
	if (!e) throw Error(O);
	if (typeof e == "function") throw Error(k);
	for (let t of w) if (typeof e[t] != "function") throw Error(A);
	let { createPaymentRequestToken: t, mountGoogleButton: n } = e;
	return {
		createPaymentBase: t,
		mountGoogleButton: n
	};
}, N = (e) => {
	if (typeof e == "string") switch (e.toLowerCase()) {
		case "black": return "black";
		case "white": return "white";
		case "white-outline":
		case "white-with-line": return "white-outline";
		default: return "black";
	}
	else return "black";
}, P = (e) => {
	if (e) {
		let { applePayOptions: t } = e;
		if (t && typeof t == "object") {
			let { buttonLanguage: e, buttonType: n, buttonStyle: r, buttonWidth: i, buttonHeight: a, buttonPadding: o, buttonBorderRadius: s, buttonBoxSizing: c } = t, l = N(r);
			return {
				buttonLanguage: e && typeof e == "string" ? `${e}` : T.buttonLanguage,
				buttonType: n && typeof n == "string" ? `${n}` : T.buttonType,
				buttonStyle: l,
				buttonWidth: i && typeof i == "string" ? `${i}` : T.buttonWidth,
				buttonHeight: a && typeof a == "string" ? `${a}` : T.buttonHeight,
				buttonPadding: o && typeof o == "string" ? `${o}` : T.buttonPadding,
				buttonBorderRadius: s && typeof s == "string" ? `${s}` : T.buttonBorderRadius,
				buttonBoxSizing: c && typeof c == "string" ? `${c}` : T.buttonBoxSizing
			};
		}
	}
	return T;
}, F = e(null), I = ({ children: e, teConnect: t }) => {
	let n = j(t), c = i(null), l = i(null), u = i(null), [d, f] = a(() => ({
		...n,
		frameRef: c,
		prCtrlRef: l,
		threeDsFrameRef: u
	})), p = (e) => f((t) => {
		let { setThreeDsSessionInterface: n, ...r } = t;
		return {
			...r,
			threeDsDecoupledInterface: e
		};
	}), { Provider: m } = F, h = new URL(n.frameUrl).origin;
	return r(() => {
		let e = (e) => {
			if (e.origin === h && e.data && typeof e.data == "string") {
				let { formId: t, prFormId: n } = JSON.parse(e.data);
				t && f((e) => {
					let { threeDsDecoupledInterface: n, ...r } = e;
					return {
						...r,
						formId: t,
						setThreeDsSessionInterface: p
					};
				}), n && f((e) => ({
					...e,
					prFormId: n
				}));
			}
		};
		return window.addEventListener("message", e, S), () => window.removeEventListener("message", e, S);
	}, [h]), /* @__PURE__ */ s(m, {
		value: d,
		children: /* @__PURE__ */ s(o, { children: e })
	});
}, L = () => n(F), R = () => {
	let { frameRef: e, formId: t, createPayment: n } = L();
	return {
		createPayment: n,
		getCurrentElements: () => ({
			elements: e.current,
			formId: t
		})
	};
}, z = () => {
	let { frameUrl: e, frameRef: t, formId: n } = L();
	return {
		frameUrl: e.includes("&threedsReq=true") ? e.replace("&threedsReq=true", "") : e,
		frameRef: t,
		formId: n
	};
}, B = ({ stylesConfig: e }) => {
	let { frameUrl: t, frameRef: n, formId: i } = z(), [o, c] = a(!1);
	return r(() => {
		if (e && i && o) {
			var t;
			if (n != null && (t = n.current) != null && t.contentWindow) {
				var r;
				n.current.contentWindow.postMessage(JSON.stringify({
					type: g,
					styles: e
				}), ((r = n.current.src) == null ? void 0 : r.split("?")[0]) || l);
			}
		}
	}, [
		n.current,
		i,
		e,
		o
	]), /* @__PURE__ */ s("iframe", {
		id: p,
		title: m,
		width: "100%",
		src: t,
		loading: "eager",
		frameBorder: "0",
		allowtransparency: "true",
		scrolling: "no",
		name: h,
		ref: n,
		allow: "payment",
		style: C,
		onLoad: () => c(!0)
	});
}, V = ({ prInterface: e, tecPrOptions: n, teInstanceProps: o }) => {
	let { createPaymentBase: l } = M(e), [u] = a(() => P(n)), { prCtrlRef: d, prFormId: f, requestClient: { instanceId: p } } = o, m = i(null), h = t(async () => {
		try {
			await l({
				instanceId: p,
				formId: f,
				controllerRef: d.current
			});
		} catch (e) {
			console.error("[TEConnect Session Error]: ", e);
		}
	}, [
		p,
		f,
		d
	]);
	return r(() => {
		let e = m.current;
		if (e) return e.addEventListener("click", h, S), () => e.removeEventListener("click", h, S);
	}, [h]), /* @__PURE__ */ c("div", {
		id: b,
		children: [/* @__PURE__ */ s("style", { children: `
                apple-pay-button {
                    --apple-pay-button-width: ${u.buttonWidth};
                    --apple-pay-button-height: ${u.buttonHeight};
                    --apple-pay-button-border-radius: ${u.buttonBorderRadius};
                    --apple-pay-button-padding: ${u.buttonPadding};
                    --apple-pay-button-box-sizing: ${u.buttonBoxSizing};
                }
            ` }), /* @__PURE__ */ s("apple-pay-button", {
			ref: m,
			id: _,
			buttonstyle: `${u.buttonStyle}`,
			type: `${u.buttonType}`,
			locale: `${u.buttonLanguage}`
		})]
	});
}, H = ({ prInterface: e, tecPrOptions: t, teInstanceProps: n }) => {
	let { mountGoogleButton: a } = M(e), o = i(null), { eventRef: c, requestClient: { instanceId: l } } = n;
	return r(() => {
		if (o.current && o.current.children.length < 1) {
			let e = {
				instanceId: l,
				eventRef: c.current
			};
			t && t.googlePayOptions && (e.googlePayOptions = t.googlePayOptions), a(y, e);
		}
	}, [t]), /* @__PURE__ */ s("div", {
		id: x,
		children: /* @__PURE__ */ s("div", {
			id: y,
			ref: o
		})
	});
}, U = () => {
	let { paymentsRequestInterface: e } = L();
	return e;
}, W = ({ paymentRequestInterface: e, tecPrOptions: t }) => {
	let n = L(), l = i(null), [u, d] = a(!1), [f, p] = a(!1);
	return r(() => {
		e && typeof e.canMakePayments == "function" && e.canMakePayments().then((e) => {
			if (e !== null) {
				let { applePay: t, googlePay: n } = e;
				d(t !== void 0 && t);
				let r = typeof n;
				p(r === "undefined" ? !1 : r === "boolean" ? n : n.result);
			}
		});
	}, [e]), /* @__PURE__ */ c(o, { children: [
		/* @__PURE__ */ s("div", {
			className: v,
			ref: l,
			children: u && /* @__PURE__ */ s("iframe", {
				id: "__tec-pr-window",
				title: "TEConnect Payment Requests Frame",
				width: "0",
				height: "0",
				src: n.prFrameUrl,
				loading: "eager",
				frameBorder: "0",
				allowtransparency: "true",
				scrolling: "no",
				name: "__tecPrFrameName",
				ref: n.prCtrlRef,
				style: {
					display: "none",
					overflow: "hidden",
					visibility: "hidden"
				}
			})
		}),
		u && /* @__PURE__ */ s(V, {
			prInterface: e,
			tecPrOptions: t,
			teInstanceProps: n
		}),
		f && /* @__PURE__ */ s(H, {
			prInterface: e,
			tecPrOptions: t,
			teInstanceProps: {
				...n,
				eventRef: l
			}
		})
	] });
}, G = () => {
	let { threeDsFrameRef: e, formId: n, createPayment: r, threeDsDecoupledInterface: i } = L(), a = t(() => ({
		elements: e.current,
		formId: n
	}), [e.current, n]);
	return i ? {
		threeDsInterface: {
			listenFor: i.listenFor,
			updateThreedsConfig: i.updateThreedsConfig
		},
		getCurrentElements: a,
		createPayment: r
	} : {
		getCurrentElements: a,
		createPayment: r
	};
}, K = "This component is designed for 3DS manual entry", q = `${K}. If you wish to opt-in for this service - please provide a 'threedsApiKey' to the 'createTEConnect' options parameter.`, J = `${K}. Please provide a valid 'threeDsConfig' object to the 'ThreeDsCardEntry' component`, Y = ({ stylesConfig: e, threeDsConfig: t }) => {
	let { frameUrl: n, threeDsFrameRef: i, threedsInterface: o, setThreeDsSessionInterface: c } = L(), [u, d] = a(null), [f, _] = a(!1), [v, y] = a(!1), b = new URL(n).origin;
	return r(() => {
		let e = (e) => {
			if (e.origin === b && e.data && typeof e.data == "string") {
				let { formId: t } = JSON.parse(e.data);
				t && y(t);
			}
		};
		return window.addEventListener("message", e, S), () => window.removeEventListener("message", e, S);
	}, [b]), r(() => {
		v && f && u && typeof c == "function" && (u.sendThreedsConfig(p), c(u));
	}, [
		v,
		u,
		c,
		f
	]), r(() => {
		if (e && v && f) {
			var t;
			if (i != null && (t = i.current) != null && t.contentWindow) {
				var n;
				i.current.contentWindow.postMessage(JSON.stringify({
					type: g,
					styles: e
				}), ((n = i.current.src) == null ? void 0 : n.split("?")[0]) || l);
			}
		}
	}, [
		i.current,
		v,
		e,
		f
	]), /* @__PURE__ */ s("iframe", {
		id: p,
		title: m,
		width: "100%",
		src: n,
		loading: "eager",
		frameBorder: "0",
		allowtransparency: "true",
		scrolling: "no",
		name: h,
		ref: i,
		allow: "payment",
		style: C,
		onLoad: () => {
			if (!t) throw Error(J);
			if (!o) throw Error(q);
			let e = o(t);
			d(e), _(!0);
		}
	});
};
//#endregion
export { B as CardEntry, I as TEConnect, W as TecPaymentRequestButtons, Y as ThreeDsCardEntry, R as useTeConnect, U as useTecPaymentsRequest, G as useTecThreeds };


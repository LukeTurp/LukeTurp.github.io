import { v4 as e, validate as t } from "uuid";
//#region src/consts/index.js
var n = "https://svc4.magensa.net", r = `${n}/TEConnect`, i = "__teConnectSecureFrame", a = "__te-connect-secure-window", o = "create_card_payment", s = "tec_threeds_init", c = "update_tec_threeds_config", l = "_create_payment_request_session", u = "_tec-payment-evt-ele", d = "hideZip", f = "tecPaymentRequest", p = "threeds", m = "threedsApiKey", h = "threedsEnvironment", g = "_threeds-challenge-frame-request", _ = "_threeds_event_emitter", ee = 61e3, v = 2e4, y = "__tec-pr-window", b = "__tecPrFrameName", x = { passive: !0 }, S = [
	"total",
	"currencyCode",
	"countryCode",
	"merchantCapabilities",
	"supportedNetworks",
	"storeDisplayName"
], C = [
	"allowedCardNetworks",
	"transactionInfo",
	"merchantName",
	"gatewayId"
], w = [
	"apiVersion",
	"apiVersionMinor",
	"callbackIntents",
	"offerInfo",
	"emailRequired",
	"shippingAddressRequired",
	"shippingAddressParameters",
	"shippingOptionRequired",
	"shippingOptionParameters"
], T = [
	...w,
	"allowedPaymentMethods",
	"existingPaymentMethodRequired",
	"environment",
	"paymentDataCallbacks",
	"prefetchGooglePaymentData"
], te = ["appleMerchantId", "googleMerchantId"], ne = [
	"buttonColor",
	"buttonType",
	"buttonLocale",
	"buttonSizeMode",
	"buttonRootNode",
	"buttonRadius"
], E = "tec-payment-request-complete", D = "tec-payment-method-selected", O = "tec-payment-request-cancel", k = "tec-payment-shipping-contact", A = "tec-payment-shipping-method", re = "confirm-token", ie = "cancel-transaction", ae = "payment-method-selection", oe = "shipping-contact-update", se = "shipping-method-update", ce = {
	baseRequest: {
		apiVersion: 2,
		apiVersionMinor: 0
	},
	allowedCardAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
	baseCardPaymentMethod: {
		type: "CARD",
		parameters: {
			allowedAuthMethods: null,
			allowedCardNetworks: null
		}
	},
	tokenizationSpecification: {
		type: "PAYMENT_GATEWAY",
		parameters: null
	},
	merchantInfo: null,
	transactionInfo: null,
	environment: "TEST"
}, le = "https://pay.google.com/gp/p/js/pay.js", ue = "https://applepay.cdn-apple.com/jsapi/1.latest/apple-pay-sdk.js", j = ["sandbox", "production"], de = "https://api-sandbox.3dsintegrator.com/v2.2", fe = "https://api.3dsintegrator.com/v2.2", pe = "Please provide a", me = "to the 'createTEConnect' function", M = "'te-connect' is designed for use within web applications.", N = "DOM element provided is not the expected node.", he = "Unable to recognize provided node", ge = "Node info object provided is not in recognized format.", P = "Response from server has been altered. Refused response, please try again", _e = "Timeout: Response not received from TEConnect", ve = "Apple Pay merchant validation failed: TEConnect returned no merchant session.", ye = "'instanceDetails' object supplied to 'createPaymentToken' function is missing a required property:", be = "'createPaymentToken' function requires an 'instanceDetails' object as a parameter", xe = "to the 'listenFor' function", Se = "'tecPaymentRequest' object was supplied, but was found to be empty. Please supply the id(s) for the desired payment request platform(s).", Ce = "'threeds' object was supplied, but 'threedsApiKey' was found to be invalid. For 3DS opt-in, please provide a valid API Key.", we = "Please supply a Payment Request object", Te = "Failed to locate TecPR event element. Please make sure TEConnect Payment Request button is mounted, and TEConnect elements are unaltered on the DOM.", Ee = "Could not locate specified node. Please ensure the node is present on the DOM, and the id supplied is accurate and unique.", De = "Please supply a TecThreeds config object", Oe = function(e) {
	return `Opt in for 3DS detected: (${e} property supplied) API Key was found to be empty. Either provide a 3DS API Key (to opt-in) or remove the property from your options object (opt-out)`;
}, ke = "[TEConnect Error]: Could not locate TEConnect window. Please ensure TEConnect is able to be mounted on the DOM", Ae = "[TEConnect Error]: TEConnect window is not in expected format. Please ensure TEConnect is able to be mounted on the DOM, and is unaltered", je = "[TEConnect Error]: 'frameBaseUrl' must be a valid https URL without query string or fragment (e.g. \"https://teconnectdemo.magensa.dev\").", F = (e) => typeof e == "string" && e !== "", Me = (e) => {
	if (!e) throw Error(`${pe} public key (pubKey) ${me}`);
	if (typeof e != "string") throw Error(`'pubKey' should be a string, but was found to be ${typeof e}`);
	return e;
}, Ne = () => {
	if (!window) throw Error(`Unable to locate Window Interface. ${M}`);
	if (!window.location) throw Error(`Unable to read 'location' property of Window Interface. ${M}`);
	let { origin: e } = window.location;
	if (e) return e;
	throw Error(`Unable to read client's origin. ${M}`);
}, I = (e, t) => !e || typeof e.nodeName != "string" ? Error(he) : e.nodeName === "IFRAME" ? t === !0 ? Pe(e, b, y) : Pe(e, i, a) : Error(N), Pe = ({ name: e, id: t }, n, r) => typeof e == "string" && typeof t == "string" ? e !== n || t !== r ? Error(N) : !0 : Error(N), Fe = (e) => {
	if (!e) return /* @__PURE__ */ Error("formId not found");
	if (!t(e)) return /* @__PURE__ */ Error("formId is not valid");
}, Ie = (e) => {
	if (!e) return { error: "Node info object not provided in 'createPayment' call." };
	if (typeof e != "object" || e.elements === void 0 || e.formId === void 0) return { error: ge };
	let t = I(e.elements);
	if (t instanceof Error) return { error: t.message };
	let n = Fe(e.formId);
	return n instanceof Error ? { error: n.message } : e;
}, Le = (e) => {
	let t = 0;
	for (let n of te) {
		let r = e[n];
		F(r) && t++;
	}
	if (t === 0) throw Error(Se);
	return e;
}, Re = (e) => {
	let t = {};
	if (typeof e == "object") {
		typeof e.hideZip == "boolean" && (t[d] = e[d]);
		let n = e[f];
		if (n && typeof n == "object") {
			let e = {};
			for (let t of te) {
				let r = n[t];
				F(r) && (e[t] = `${r}`);
			}
			t[f] = Le(e);
		}
		let r = e[p];
		if (r) {
			let e = typeof r == "object" ? r[m] : void 0;
			if (typeof e != "string" || e.length <= 10) throw Error(Ce);
			t[p] = r;
		}
		if (e.frameBaseUrl !== void 0) {
			let n = e.frameBaseUrl, r;
			try {
				r = new URL(n);
			} catch {
				throw Error(je);
			}
			if (r.protocol !== "https:" || r.search !== "" || r.hash !== "") throw Error(je);
			t.frameBaseUrl = (r.origin + r.pathname).replace(/\/+$/, "");
		}
	}
	return t;
}, ze = (e) => {
	if (typeof e != "object" || !e) return { error: be };
	let { instanceId: t, formId: n, controllerRef: r } = e;
	if (!F(t)) return { error: `${ye} 'instanceId'` };
	if (!F(n)) return { error: `${ye} 'formId'` };
	let i = Fe(n);
	if (i instanceof Error) return { error: i.message };
	let a = I(r, !0);
	return a instanceof Error ? { error: a.message } : e;
}, L = (e, t) => {
	if (typeof e != "object") throw Error(we);
	for (let n of t) if (e[n] === void 0) throw Error(`'${n}' is a required property for a Payment Request object, but was found to be 'undefined'`);
}, Be = (e) => {
	let t = [
		"allowPrepaidCards",
		"allowCreditCards",
		"assuranceDetailsRequired",
		"billingAddressRequired"
	], n = {
		allowedAuthMethods: e.allowedAuthMethods || ce.allowedCardAuthMethods,
		allowedCardNetworks: e.allowedCardNetworks
	};
	for (let r of t) typeof e[r] == "boolean" && (n[r] = e[r]);
	return e.billingAddressParameters && (n.billingAddressParameters = e.billingAddressParameters), n;
}, Ve = (e, t) => {
	let n = ce;
	n.merchantInfo = {
		merchantName: e.merchantName,
		merchantId: t
	}, n.baseCardPaymentMethod.parameters = Be(e), n.transactionInfo = e.transactionInfo, n.tokenizationSpecification.parameters = {
		gateway: "magensa",
		gatewayMerchantId: e.gatewayId
	};
	for (let t of T) e[t] !== void 0 && (n[t] = e[t]);
	return n;
}, He = (e) => {
	let { baseRequest: t, baseCardPaymentMethod: n, allowedPaymentMethods: r, existingPaymentMethodRequired: i } = e, a = [n];
	if (r && r.length > 0) for (let e of r) a.push(e);
	let o = {
		...t,
		allowedPaymentMethods: a
	};
	return i === !0 && (o.existingPaymentMethodRequired = i), o;
}, Ue = (e) => {
	let { baseCardPaymentMethod: t, tokenizationSpecification: n, allowedPaymentMethods: r } = e, i = [{
		...t,
		tokenizationSpecification: n
	}];
	if (r && r.length > 0) for (let e of r) i.push({
		...e,
		tokenizationSpecification: n
	});
	return i;
}, We = (e) => {
	let { baseRequest: t, merchantInfo: n, transactionInfo: r } = e, i = {
		...t,
		allowedPaymentMethods: Ue(e),
		transactionInfo: r,
		merchantInfo: n
	};
	for (let t of w) e[t] !== void 0 && (i[t] = e[t]);
	return i;
}, Ge = (e) => {
	let { environment: t, merchantInfo: n, paymentDataCallbacks: r } = e, i = {
		environment: t,
		merchantInfo: n
	};
	return r && (i.paymentDataCallbacks = r), i;
}, Ke = (e, t) => {
	if (typeof e != "object") throw Error(we);
	let n = {}, { appleMerchantId: r, googleMerchantId: i } = t;
	if (r && (e.applePay ? (L(e.applePay, S), n.applePay = e.applePay) : (L(e, S), n.applePay = e), n.applePay.additionalOptions)) {
		let e = n.applePay.additionalOptions, t = {};
		if (typeof e.forceButtonDisplay == "boolean" && (t = { forceApplePayButton: e.forceButtonDisplay }), e.displayButtonWhitelist) {
			let n = e.displayButtonWhitelist;
			Array.isArray(n) && n.length > 0 && (t = {
				...t,
				appleDisplayWhitelist: [...n]
			});
		}
		Object.keys(t).length > 0 && (n.tecOptions = t);
	}
	return i && (e.googlePay ? (L(e.googlePay, C), n.googlePay = Ve(e.googlePay, i)) : (L(e, C), n.googlePay = Ve(e, i))), n;
}, qe = (e) => {
	if (e) {
		let t = e.closest("div");
		if (t) return t;
		let n = document.getElementsByClassName(u);
		if (n && n.length > 0) return n[0];
	}
	throw Error(Te);
}, Je = (e) => {
	if (e && e.className === "_tec-payment-evt-ele") return e;
	throw Error(Te);
}, R = (e) => (t, n) => {
	let r = new CustomEvent(t, { detail: n });
	e.dispatchEvent(r);
}, Ye = (e, t) => {
	if (typeof t != "function") throw Error(`Please supply a function as the listener argument ${xe}`);
	if (typeof e != "string") throw Error(`Please specify the event ${xe}`);
	return {
		eventToLower: e.toLowerCase(),
		suppliedListener: t
	};
}, Xe = (e) => {
	if (e && typeof e == "object") {
		let { errorType: t } = e;
		if (typeof t == "string") switch (t) {
			case "failure": return {
				error: "unknown",
				message: e.message
			};
			case "addressInvalid": return {
				error: "addressUnserviceable",
				message: e.message
			};
			default: return;
		}
	}
	return {
		error: "unknown",
		message: ""
	};
}, Ze = (e) => {
	let t = [];
	for (let n of e) if (n instanceof window.ApplePayError) t.push(n);
	else {
		let e = Xe(n);
		e !== void 0 && t.push(new window.ApplePayError(e.error, "countryCode", e.message));
	}
	return t;
}, Qe = (e) => {
	if (e) {
		if (typeof e == "string") return { status: e.toLowerCase() === "success" ? ApplePaySession.STATUS_SUCCESS : ApplePaySession.STATUS_FAILURE };
		if (e && typeof e.status == "number") return e.errors && e.errors.length > 0 && (e.errors = Ze(e.errors)), e;
	}
	return console.error("[Token Exchange Connect Error]: Unrecognized completion result. Completing payment with failure."), { status: ApplePaySession.STATUS_FAILURE };
};
function $e(e) {
	let t = document.getElementById("_apple-pay-browser-api");
	if (t) t.removeEventListener("load", e, x), t.addEventListener("load", e, x), t.removeEventListener("error", e, x), t.addEventListener("error", e, x);
	else {
		let t = document.createElement("script");
		t.src = ue, t.async = !0, t.id = "_apple-pay-browser-api", t.crossOrigin = "anonymous", t.dataset.applePaySdk = "1", t.addEventListener("load", e, x), t.addEventListener("error", e, x), document.head.appendChild(t);
	}
}
function et(e) {
	let t = document.getElementById("_google-pay-api");
	if (t) t.removeEventListener("load", e, x), t.addEventListener("load", e, x);
	else {
		let t = document.createElement("script");
		t.src = le, t.async = !0, t.id = "_google-pay-api", t.addEventListener("load", e, x), document.body.appendChild(t);
	}
}
var tt = (e) => {
	let t = {};
	for (let n of ne) {
		let r = e[n];
		(r || n === "buttonRadius" && r === 0) && (t[n] = r);
	}
	return t;
}, nt = (e, t) => {
	if (!t.threedsApiKey) throw Error(Oe(m));
	if (typeof e != "object") throw Error(De);
	if (typeof (e == null ? void 0 : e.amount) != "number") throw Error("`amount` is required for the 3DS configuration object, and should be of type `Number`");
	let n = e == null ? void 0 : e.challengeNodeId;
	if (typeof n != "string" || n === "") throw Error("`challengeNodeId` is required for the 3DS configuration object");
	if (!t.requestOrigin || typeof t.requestOrigin != "string" || !t.requestOrigin.startsWith("http")) throw Error(`[TEConnect Error]: Unable to read client's origin. ${M}`);
	if (typeof t.threedsEnvironment != "string") throw Error(`'${h}' is expected to be a 'string', but was found to be ${typeof t[h]}`);
	if (!j.find((e) => e.toLowerCase() === t.threedsEnvironment.toLowerCase())) throw Error(`'${h}' was an unrecognized value. Expected either '${j[0]}' or '${j[1]}'.`);
	let { syncTecThreeDsTimeout: r } = t;
	return typeof r == "function" && r(e.transactionForcedTimeout), e;
}, rt = () => ({
	browserAcceptHeader: "application/json",
	browserJavaEnabled: !1,
	browserJavascriptEnabled: !0,
	browserLanguage: navigator.language,
	browserColorDepth: window.screen.colorDepth.toString(),
	browserTZ: (/* @__PURE__ */ new Date()).getTimezoneOffset().toString(),
	browserScreenWidth: window.screen.width.toString(),
	browserScreenHeight: window.screen.height.toString(),
	browserUserAgent: navigator.userAgent
}), it = (e) => {
	let t = document.getElementById(_);
	if (t) {
		let e = t.cloneNode(!1);
		return t.replaceWith(e), e;
	}
	let n = document.createElement("div");
	return n.id = _, n.style.display = "none", e.appendChild(n), n;
}, at = (e) => typeof HTMLElement == "object" ? e instanceof HTMLElement : typeof e == "object" && !!e && e.nodeType === 1 && typeof e.nodeName == "string";
function ot(e) {
	return at(e) ? e : null;
}
function st(e) {
	return !e || typeof e != "object" || !Array.isArray(e) ? [] : e;
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/checkPrivateRedeclaration.js
function ct(e, t) {
	if (t.has(e)) throw TypeError("Cannot initialize the same private elements twice on an object");
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/classPrivateFieldInitSpec.js
function z(e, t, n) {
	ct(e, t), t.set(e, n);
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/typeof.js
function B(e) {
	"@babel/helpers - typeof";
	return B = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, B(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/toPrimitive.js
function lt(e, t) {
	if (B(e) != "object" || !e) return e;
	var n = e[Symbol.toPrimitive];
	if (n !== void 0) {
		var r = n.call(e, t || "default");
		if (B(r) != "object") return r;
		throw TypeError("@@toPrimitive must return a primitive value.");
	}
	return (t === "string" ? String : Number)(e);
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/toPropertyKey.js
function ut(e) {
	var t = lt(e, "string");
	return B(t) == "symbol" ? t : t + "";
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/defineProperty.js
function V(e, t, n) {
	return (t = ut(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/assertClassBrand.js
function dt(e, t, n) {
	if (typeof e == "function" ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
	throw TypeError("Private element is not present on this object");
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/classPrivateFieldGet2.js
function H(e, t) {
	return e.get(dt(e, t));
}
//#endregion
//#region \0@oxc-project+runtime@0.147.0/helpers/esm/classPrivateFieldSet2.js
function U(e, t, n) {
	return e.set(dt(e, t), n), n;
}
//#endregion
//#region src/tecPaymentRequest/tecPrProps.js
var W = /* @__PURE__ */ new WeakMap(), G = /* @__PURE__ */ new WeakMap(), K = /* @__PURE__ */ new WeakMap(), q = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ new WeakMap(), ft = /* @__PURE__ */ new WeakMap(), pt = /* @__PURE__ */ new WeakMap(), mt = /* @__PURE__ */ new WeakMap(), ht = /* @__PURE__ */ new WeakMap(), gt = /* @__PURE__ */ new WeakMap(), _t = class {
	get paymentRequestObj() {
		return H(W, this);
	}
	set paymentRequestObj(e) {
		U(W, this, e);
	}
	get paymentRequestIds() {
		return H(G, this);
	}
	set paymentRequestIds(e) {
		U(G, this, e);
	}
	get googlePayClient() {
		return H(K, this);
	}
	set googlePayClient(e) {
		U(K, this, e);
	}
	get customerPaymentListener() {
		return H(q, this);
	}
	set customerPaymentListener(e) {
		U(q, this, e);
	}
	get customerCancelListener() {
		return H(J, this);
	}
	set customerCancelListener(e) {
		U(J, this, e);
	}
	get paymentMethodListener() {
		return H(Y, this);
	}
	set paymentMethodListener(e) {
		U(Y, this, e);
	}
	get shippingContactListener() {
		return H(ft, this);
	}
	set shippingContactListener(e) {
		U(ft, this, e);
	}
	get shippingMethodListener() {
		return H(pt, this);
	}
	set shippingMethodListener(e) {
		U(pt, this, e);
	}
	get googleCanMakePaymentsResult() {
		return H(mt, this);
	}
	set googleCanMakePaymentsResult(e) {
		U(mt, this, e);
	}
	get appleCanMakePaymentsResult() {
		return H(ht, this);
	}
	set appleCanMakePaymentsResult(e) {
		U(ht, this, e);
	}
	get applePayCapability() {
		return H(gt, this);
	}
	set applePayCapability(e) {
		U(gt, this, e);
	}
	constructor(e, t) {
		z(this, W, void 0), z(this, G, void 0), z(this, K, void 0), z(this, q, void 0), z(this, J, void 0), z(this, Y, void 0), z(this, ft, void 0), z(this, pt, void 0), z(this, mt, void 0), z(this, ht, void 0), z(this, gt, void 0), V(this, "getGooglePayCanMakePayments", (e) => {
			et(() => {
				if (window.google) this.googlePayClient || (this.googlePayClient = new google.payments.api.PaymentsClient(Ge(e))), this.googlePayClient.isReadyToPay(He(e)).then((e) => {
					this.googleCanMakePaymentsResult = e.paymentMethodPresent === void 0 ? e.result : e;
				}).catch((e) => {
					console.error(e), this.googleCanMakePaymentsResult = !1;
				});
				else throw Error("Google Pay API was loaded, but `window.google` is unavailable");
			});
		}), V(this, "applePayCompatibilityCheck", (e) => async () => {
			if (window.ApplePaySession) {
				var t, n;
				if (typeof ApplePaySession.applePayCapabilities == "function") {
					var r;
					let t = typeof ((r = this.paymentRequestObj.applePay) == null ? void 0 : r.applePayVersion) == "number" ? this.paymentRequestObj.applePay.applePayVersion : 3;
					try {
						if (ApplePaySession.supportsVersion(t)) {
							var i, a;
							let t = await window.ApplePaySession.applePayCapabilities(e);
							if (this.applePayCapability = t == null ? void 0 : t.paymentCredentialStatus, ((i = this.paymentRequestObj) == null || (i = i.tecOptions) == null ? void 0 : i.forceApplePayButton) === !0) {
								this.appleCanMakePaymentsResult = !0;
								return;
							}
							let n = st((a = this.paymentRequestObj) == null || (a = a.tecOptions) == null ? void 0 : a.appleDisplayWhitelist);
							switch (t == null ? void 0 : t.paymentCredentialStatus) {
								case "paymentCredentialsAvailable":
								case "paymentCredentialStatusUnknown":
									this.appleCanMakePaymentsResult = !0;
									return;
								case "paymentCredentialsUnavailable":
									this.appleCanMakePaymentsResult = n.includes("paymentCredentialsUnavailable");
									return;
								case "applePayUnsupported":
									this.appleCanMakePaymentsResult = n.includes("applePayUnsupported");
									return;
								default:
									this.appleCanMakePaymentsResult = !1;
									return;
							}
						} else console.warn(`ApplePay version: ${t} is not supported on this browser. Initiating fallback legacy compatability check.`);
					} catch (e) {
						console.error(e), this.appleCanMakePaymentsResult = !1;
						return;
					}
				}
				this.appleCanMakePaymentsResult = ((t = (n = ApplePaySession).canMakePayments) == null ? void 0 : t.call(n)) === !0;
				return;
			}
			this.appleCanMakePaymentsResult = !1;
		}), V(this, "applePayCanMakePayments", async (e) => {
			var t;
			let n = this.applePayCompatibilityCheck(e);
			if (typeof ((t = window.ApplePaySession) == null ? void 0 : t.applePayCapabilities) != "function") $e(n);
			else return await n();
		}), U(W, this, e), U(G, this, t);
		let { appleMerchantId: n, googleMerchantId: r } = t;
		r && this.getGooglePayCanMakePayments(e.googlePay), n && this.applePayCanMakePayments(n);
	}
}, vt = class extends _t {
	constructor(t, i, a) {
		var o, s;
		super(t, i), V(this, "updatePaymentRequest", (e) => {
			var t, n, r, i;
			let a = Ke(e, this.paymentRequestIds), o = (t = this.paymentRequestObj) == null ? void 0 : t.tecOptions, s = a == null ? void 0 : a.tecOptions;
			this.paymentRequestObj = a;
			let { appleMerchantId: c } = this.paymentRequestIds, l = (o == null ? void 0 : o.forceApplePayButton) === !0 != ((s == null ? void 0 : s.forceApplePayButton) === !0), u = JSON.stringify((n = o == null ? void 0 : o.appleDisplayWhitelist) == null ? [] : n) !== JSON.stringify((r = s == null ? void 0 : s.appleDisplayWhitelist) == null ? [] : r), d = typeof ((i = window.ApplePaySession) == null ? void 0 : i.applePayCapabilities) == "function";
			c && d && (l || u) && (this.appleCanMakePaymentsResult = void 0, this.applePayCanMakePayments(c));
		}), V(this, "appleCanMakePayments", () => new Promise((e) => {
			let t = () => this.applePayCapability ? {
				applePay: this.appleCanMakePaymentsResult,
				applePaymentCredentialStatus: this.applePayCapability
			} : { applePay: this.appleCanMakePaymentsResult };
			if (typeof this.appleCanMakePaymentsResult == "boolean") return e(t());
			{
				let n = setTimeout(() => {
					this.appleCanMakePaymentsResult === void 0 && (this.appleCanMakePaymentsResult = !1);
				}, v), r = (e) => new Promise((e) => {
					if (typeof this.appleCanMakePaymentsResult == "boolean") return clearTimeout(n), e(t());
					setTimeout(() => e(r()), 200);
				});
				return e(r());
			}
		})), V(this, "googleCanMakePayments", () => new Promise((e) => {
			if (this.googleCanMakePaymentsResult !== void 0) return e({ googlePay: this.googleCanMakePaymentsResult });
			{
				let t = setTimeout(() => {
					this.googleCanMakePaymentsResult === void 0 && (this.googleCanMakePaymentsResult = !1);
				}, v), n = (e) => new Promise((e) => {
					this.googleCanMakePaymentsResult === void 0 ? setTimeout(() => e(n()), 200) : (clearTimeout(t), e({ googlePay: this.googleCanMakePaymentsResult }));
				});
				return e(n());
			}
		})), V(this, "canMakePayments", (e) => new Promise((e) => {
			let { appleMerchantId: t, googleMerchantId: n } = this.paymentRequestIds;
			if (t && n) {
				let t = {};
				return this.appleCanMakePayments().then((e) => Object.assign(t, e)).then((n) => this.googleCanMakePayments().then((r) => (Object.assign(t, r), e(n.applePay === !1 && r.googlePay === !1 ? null : t))));
			}
			if (t) return this.appleCanMakePayments().then((t) => e(t.applePay === !1 ? null : t));
			if (n) return this.googleCanMakePayments().then((t) => e(t.googlePay === !1 ? null : t));
		})), V(this, "listenFor", (e, t) => {
			let { eventToLower: n, suppliedListener: r } = Ye(e, t), i = ({ detail: e }) => e ? r(e) : void 0;
			switch (n) {
				case re:
					this.customerPaymentListener = i;
					break;
				case ie:
					this.customerCancelListener = i;
					break;
				case ae:
					this.paymentMethodListener = i;
					break;
				case oe:
					this.shippingContactListener = i;
					break;
				case se:
					this.shippingMethodListener = i;
					break;
				default: return;
			}
		}), V(this, "createPaymentRequestToken", async (t) => {
			var n;
			let r = typeof ((n = this.paymentRequestObj.applePay) == null ? void 0 : n.applePayVersion) == "number" ? this.paymentRequestObj.applePay.applePayVersion : 3, { additionalOptions: i, ...a } = this.paymentRequestObj.applePay, o = new ApplePaySession(r, a), s = this.paymentRequestObj.applePay.storeDisplayName, { instanceId: c, formId: u, controllerRef: d, error: f } = ze(t), p = qe(d), m = R(p), h = () => {
				typeof this.customerPaymentListener == "function" && (p.removeEventListener(E, this.customerPaymentListener, x), p.addEventListener(E, this.customerPaymentListener, x));
			}, g = (e) => {
				m(E, e), p.removeEventListener(E, this.customerPaymentListener, x);
			};
			if (h(), f) return g({ error: f });
			let { appleMerchantId: _ } = this.paymentRequestIds, v = e(), y = null, b = null, S = !1;
			o.onvalidatemerchant = (e) => {
				var t;
				let n = (t = e == null ? void 0 : e.validationURL) == null ? "" : t;
				F(n) && d.contentWindow.postMessage(JSON.stringify({
					type: l,
					vUrl: n,
					iid: c,
					sessionSignature: v,
					prFormId: u,
					storeDisplayName: s,
					appleMerchantId: _
				}), this.framePath);
			}, typeof this.customerCancelListener == "function" && (p.removeEventListener(O, this.customerCancelListener, x), p.addEventListener(O, this.customerCancelListener, x)), o.oncancel = (e) => {
				var t;
				let n = (t = e == null ? void 0 : e.sessionError) == null ? {
					code: "user-dismiss",
					info: {}
				} : t;
				y || (S = !0, clearTimeout(b), window.removeEventListener("message", C, x), p.removeEventListener(E, this.customerPaymentListener, x)), m(O, { sessionError: n }), p.removeEventListener(D, this.paymentMethodListener, x), p.removeEventListener(k, this.shippingContactListener, x), p.removeEventListener(A, this.shippingMethodListener, x), p.removeEventListener(O, this.customerCancelListener, x);
			}, typeof this.paymentMethodListener == "function" && (p.removeEventListener(D, this.paymentMethodListener, x), p.addEventListener(D, this.paymentMethodListener, x), o.onpaymentmethodselected = ({ paymentMethod: e }) => {
				m(D, {
					paymentMethod: e,
					completePaymentMethodSelection: (e) => {
						o.completePaymentMethodSelection(e);
					}
				});
			}), typeof this.shippingContactListener == "function" && (p.removeEventListener(k, this.shippingContactListener, x), p.addEventListener(k, this.shippingContactListener, x), o.onshippingcontactselected = ({ shippingContact: e }) => {
				m(k, {
					shippingContact: e,
					completeShippingContactSelection: (e) => {
						if (!e) throw Error("Please provide a 'shippingContactUpdate' object");
						if (e.errors && e.errors.length > 0) {
							let { errors: t } = e;
							e.errors = Ze(t);
						}
						o.completeShippingContactSelection(e);
					}
				});
			}), typeof this.shippingMethodListener == "function" && (p.removeEventListener(A, this.shippingMethodListener, x), p.addEventListener(A, this.shippingMethodListener, x), o.onshippingmethodselected = ({ shippingMethod: e }) => {
				m(A, {
					shippingMethod: e,
					completeShippingMethodSelection: (e) => {
						o.completeShippingMethodSelection(e);
					}
				});
			});
			let C = (e) => {
				if (this.frameOrigin === e.origin) {
					let { data: t } = e;
					if (F(t)) {
						let { type: e, sessionNonce: n, sessionObj: r, iid: i, error: a } = JSON.parse(t);
						if (e === "_payment-requests-session-resp" && i === c) {
							if (n === v) {
								clearTimeout(b);
								let e = a == null ? r == null ? void 0 : r.error : a;
								if (e || !r) {
									y = { error: e == null ? ve : e }, window.removeEventListener("message", C, x), typeof o.abort == "function" && o.abort();
									return;
								}
								o.completeMerchantValidation(r), o.onpaymentauthorized = (e) => {
									p.removeEventListener(E, this.customerPaymentListener, x), p.addEventListener(E, this.customerPaymentListener, x);
									let t = (e) => {
										let t = Qe(e);
										o.completePayment(t), p.removeEventListener(E, this.customerPaymentListener, x);
									}, n = {
										type: "applePay",
										token: e.payment.token
									};
									e.payment.billingContact && (n.billingContact = e.payment.billingContact), e.payment.shippingContact && (n.shippingContact = e.payment.shippingContact), y = {
										tokenDetails: n,
										completePayment: t
									}, p.removeEventListener(O, this.customerCancelListener, x), p.removeEventListener(D, this.paymentMethodListener, x), p.removeEventListener(k, this.shippingContactListener, x), p.removeEventListener(A, this.shippingMethodListener, x);
								};
							} else y = { error: P };
							window.removeEventListener("message", C, x);
						}
					}
				}
			};
			b = setTimeout(() => {
				y || (y = { error: _e }, window.removeEventListener("message", C, x));
			}, ee), window.addEventListener("message", C, x);
			let w = () => y.error ? g(y) : m(E, y), T = (e) => new Promise((e) => {
				if (y) return e(w());
				if (S) return e();
				setTimeout(() => e(T()), 400);
			});
			return o.begin(), await T();
		}), V(this, "mountGoogleButton", (e, t) => {
			let { eventRef: n, googlePayOptions: r } = t, i = Je(n), a = R(i), o = typeof e == "string" ? document.getElementById(e) : ot(e);
			if (!o) throw Error(Ee);
			if (this.googlePayClient) {
				let e = () => (i.removeEventListener(E, this.customerPaymentListener, x), i.addEventListener(E, this.customerPaymentListener, x), this.googlePayClient.loadPaymentData(We(this.paymentRequestObj.googlePay)).then((e) => {
					if (e && e.paymentMethodData) {
						let { tokenizationData: t, ...n } = e.paymentMethodData;
						typeof t == "object" && (a(E, { tokenDetails: {
							type: "googlePay",
							token: t.token,
							additionalData: {
								...n,
								tokenizationDataType: t.type
							}
						} }), i.removeEventListener(E, this.customerPaymentListener, x));
					}
				}).catch((e) => {
					a(E, { error: e.message || e.statusCode }), console.error(e), i.removeEventListener(E, this.customerPaymentListener, x);
				})), t = { allowedPaymentMethods: Ue(this.paymentRequestObj.googlePay) };
				if (r) {
					let n = tt(r);
					t.onClick = typeof r.preClick == "function" ? () => (r.preClick(), e()) : e, Object.assign(t, n);
				} else t.onClick = e;
				let n = this.googlePayClient.createButton(t);
				if (o.appendChild(n), this.paymentRequestObj.googlePay.prefetchGooglePaymentData === !0) {
					let e = We(this.paymentRequestObj.googlePay);
					e.transactionInfo = {
						totalPriceStatus: "NOT_CURRENTLY_KNOWN",
						currencyCode: e.transactionInfo && e.transactionInfo.currencyCode || "USD"
					}, this.googlePayClient.prefetchPaymentData();
				}
			}
		}), this.frameOrigin = (o = a == null ? void 0 : a.frameOrigin) == null ? n : o, this.framePath = (s = a == null ? void 0 : a.framePath) == null ? r : s;
	}
}, yt = class {
	constructor(e, t, n) {
		let r = new vt(e, t, n);
		this.createPaymentRequestToken = r.createPaymentRequestToken, this.canMakePayments = r.canMakePayments, this.listenFor = r.listenFor, this.updatePaymentRequest = r.updatePaymentRequest, this.mountGoogleButton = r.mountGoogleButton;
	}
}, bt = (e, t) => (n) => new yt(Ke(n, e), e, t), X = "TecThreeDs_MessageQueue", xt = /* @__PURE__ */ new WeakMap(), Z = /* @__PURE__ */ new WeakMap(), St = /* @__PURE__ */ new WeakMap(), Ct = /* @__PURE__ */ new WeakMap(), wt = /* @__PURE__ */ new WeakMap(), Tt = /* @__PURE__ */ new WeakMap(), Et = /* @__PURE__ */ new WeakMap(), Dt = /* @__PURE__ */ new WeakMap(), Ot = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakMap(), $ = /* @__PURE__ */ new WeakMap(), At = class {
	get threedsApiKey() {
		return H(xt, this);
	}
	get threedsConfig() {
		return H(Z, this);
	}
	set threedsConfig(e) {
		U(Z, this, e);
	}
	get clientOrigin() {
		return H(St, this);
	}
	get instanceId() {
		return H(Ct, this);
	}
	get threedsEnv() {
		return H(wt, this);
	}
	get tecMsgNode() {
		return H(Tt, this);
	}
	set tecMsgNode(e) {
		U(Tt, this, e);
	}
	get challengeNode() {
		return H(Et, this);
	}
	set challengeNode(e) {
		U(Et, this, e);
	}
	get statusNode() {
		return H(Dt, this);
	}
	set statusNode(e) {
		U(Dt, this, e);
	}
	get threedsStatusListener() {
		return H(Ot, this);
	}
	set threedsStatusListener(e) {
		U(Ot, this, e);
	}
	get statusEmitter() {
		return H(kt, this);
	}
	set statusEmitter(e) {
		U(kt, this, e);
	}
	get frameOrigin() {
		return H(Q, this);
	}
	get framePath() {
		return H($, this);
	}
	constructor(e, { threedsApiKey: t, requestOrigin: i, instanceId: a, threedsEnvironment: o, frameOrigin: l, framePath: u }) {
		z(this, xt, void 0), z(this, Z, void 0), z(this, St, void 0), z(this, Ct, void 0), z(this, wt, void 0), z(this, Tt, void 0), z(this, Et, void 0), z(this, Dt, void 0), z(this, Ot, function() {}), z(this, kt, void 0), z(this, Q, void 0), z(this, $, void 0), V(this, "addThreedsListener", (e, t) => {
			let n = {
				listenFunc: e,
				listenType: t
			};
			if (!(window[X] instanceof Array)) window[X] = [n];
			else {
				let e = window[X].find(({ listenType: e }) => e === t);
				if (e) {
					window.removeEventListener("message", e.listenFunc, x);
					let t = window[X].indexOf(e);
					window[X].splice(t, 1);
				}
				window[X].push(n);
			}
			window.removeEventListener("message", e, x), window.addEventListener("message", e, x);
			function r() {
				window.removeEventListener("message", e, x);
			}
			window.addEventListener("beforeunload", r, x);
		}), V(this, "challengeListener", (e) => {
			if (e.origin === this.frameOrigin) {
				let { data: t } = e;
				if (t && typeof t == "string") {
					let { type: e, challengeObj: n } = JSON.parse(t);
					if (e === "threeds_assert_challenge" && n) {
						let e = document.createElement("iframe");
						e.id = g, e.loading = "eager", e.style.display = "none";
						let t = (n) => {
							if (n.origin === this.frameOrigin) {
								let { data: r } = n;
								if (r && typeof r == "string") {
									let { type: n } = JSON.parse(r);
									n === "challenge_complete_hide_frame" && (window.removeEventListener("message", t, x), e.style.display = "none");
								}
							}
						}, r = document.createElement("form");
						r.name = "sendChallenge", r.action = n.acsURL, r.method = "post";
						let i = document.createElement("input");
						i.hidden = !0, i.value = n.creq, i.name = "creq", r.appendChild(i), e.addEventListener("load", (() => {
							let n = 0;
							return () => {
								n++, n === 2 && setTimeout(() => {
									e.removeAttribute("style"), r.submit();
								}, 1e3), this.addThreedsListener(t, "hideChallenge");
							};
						})()), this.challengeNode.appendChild(e), e.contentWindow.document.open(), e.contentWindow.document.write("<html><body></body></html>"), e.contentWindow.document.close(), e.contentWindow.document.body.appendChild(r);
					}
				}
			}
		}), V(this, "updateThreedsConfig", (e) => {
			var t;
			let n = I(this.tecMsgNode);
			if (n instanceof Error) throw n;
			if (!((t = this.tecMsgNode) != null && t.contentWindow)) throw Error(Ae);
			let { challengeNodeId: r, ...i } = nt(e, {
				[m]: this.threedsApiKey,
				requestOrigin: this.clientOrigin,
				threedsEnvironment: this.threedsEnv
			}), a = {
				...i,
				browser: rt(),
				threeDSRequestorURL: this.threedsEnv === "sandbox" && !this.clientOrigin.startsWith("https") ? this.frameOrigin : this.clientOrigin
			}, o = document.getElementById(r);
			if (!o) throw Error("Unable to find node specified for 3DS challenge. Please provide a valid node `id` string.");
			this.challengeNode !== o && (this.challengeNode = o), this.threedsConfig = a, this.tecMsgNode.contentWindow.postMessage(JSON.stringify({
				type: c,
				iid: this.instanceId,
				threedsConfig: a,
				threedsKey: this.threedsApiKey,
				threedsBaseUrl: this.threedsEnv === "production" ? fe : de
			}), this.framePath);
		}), V(this, "sendThreedsConfig", (e) => {
			if (!this.tecMsgNode) {
				let t = document.getElementById(e);
				if (!t || !(t != null && t.contentWindow)) throw Error(ke);
				t.contentWindow.postMessage(JSON.stringify({
					type: s,
					iid: this.instanceId,
					threedsConfig: this.threedsConfig,
					threedsKey: this.threedsApiKey,
					threedsBaseUrl: this.threedsEnv === "production" ? fe : de
				}), this.framePath), this.tecMsgNode = t, this.addThreedsListener(this.challengeListener, "challengeListener");
			}
		}), V(this, "theedsStatusListener", (e) => {
			if (e.origin === this.frameOrigin) {
				let { data: t } = e;
				if (t && typeof t == "string") {
					let { type: e, statusObj: n } = JSON.parse(t);
					e === "threeds_status_update_trigger" && n && this.statusEmitter("threeds-status-update", n);
				}
			}
		}), V(this, "listenFor", (e, t) => {
			let { eventToLower: n, suppliedListener: r } = Ye(e, t), i = (e) => r(e.detail);
			n === "threeds-status" && (this.statusNode.removeEventListener("threeds-status-update", this.threedsStatusListener, x), this.threedsStatusListener = i, this.statusNode.removeEventListener("threeds-status-update", this.threedsStatusListener, x), this.statusNode.addEventListener("threeds-status-update", this.threedsStatusListener, x), this.addThreedsListener(this.theedsStatusListener, "statusListener"));
		}), V(this, "threedsInit", (e, t, n) => {
			let { challengeNodeId: r, ...i } = e;
			this.threedsConfig = {
				...i,
				browser: rt(),
				threeDSRequestorURL: n === "sandbox" ? H(Q, this) : t
			};
			let a = document.getElementById(r);
			if (!a) throw Error("Unable to find node specified for 3DS challenge. Please provide a valid node `id` string.");
			this.challengeNode = a, this.statusNode = it(a), this.statusEmitter = R(this.statusNode);
		}), U(xt, this, t), U(Ct, this, a), U(St, this, i), U(Q, this, l == null ? n : l), U($, this, u == null ? r : u), this.threedsInit(e, i, o), U(wt, this, o.toLowerCase());
	}
}, jt = class {
	constructor(e, t) {
		let n = new At(e, t);
		this.sendThreedsConfig = n.sendThreedsConfig, this.listenFor = n.listenFor, this.updateThreedsConfig = n.updateThreedsConfig;
	}
}, Mt = (e) => (t) => new jt(nt(t, e), e), Nt = (t, i) => {
	let { hideZip: a, tecPaymentRequest: s, threeds: c, frameBaseUrl: l } = Re(i), u = Me(t), d = e(), f = Ne(), p = {}, m = ee, h = l == null ? r : l, g = l ? new URL(l).origin : n, _ = {
		frameOrigin: g,
		framePath: h
	};
	p.requestClient = {
		instanceId: d,
		pubKey: u,
		requestOrigin: f
	};
	let v = `${h}/?instanceId=${d}&pubKey=${u}&requestOrigin=${btoa(f)}`;
	if (p.frameUrl = `${v}&hideZip=${a === !0 ? "true" : "false"}`, c) {
		let { threedsApiKey: e, threedsEnvironment: t } = c;
		p.frameUrl += "&threedsReq=true", p.threedsInterface = Mt({
			threedsApiKey: e,
			requestOrigin: f,
			instanceId: d,
			threedsEnvironment: t || "sandbox",
			syncTecThreeDsTimeout: (e) => {
				if (typeof e == "string" && e !== "" && e.length <= 3) {
					let t = e.includes(".") ? parseFloat(e) : parseInt(e);
					typeof t == "number" && !Number.isNaN(t) && t > 0 && (m = t >= 10 ? t * 1e3 : 1e4);
				}
			},
			..._
		});
	}
	return s && (p.prFrameUrl = `${v}&enableTecPR=true`, p.paymentsRequestInterface = bt(s, _)), p.createPayment = async (t, n) => {
		let { elements: r, formId: i, error: a } = Ie(t);
		if (a) return { error: a };
		let s = e(), c = null, l = null, u = (e) => {
			if (e.origin === g) {
				let t = JSON.parse(e.data);
				if (t && t.type === "token_exchange_response") {
					if (clearTimeout(l), t.nonce !== void 0) {
						let { nonce: e, type: n, ...r } = t;
						c = e === s ? r : { error: P };
					} else c = t.error === void 0 ? { error: P } : { error: t.error };
					window.removeEventListener("message", u, x);
				}
			}
		};
		l = setTimeout(() => {
			c || (c = { error: _e }, window.removeEventListener("message", u, x));
		}, m), window.addEventListener("message", u, x), r.contentWindow.postMessage(JSON.stringify({
			type: o,
			formId: i,
			nonce: s,
			billingZip: n || null
		}), h);
		let d = (e) => new Promise((e) => c ? e(c) : setTimeout(() => e(d()), 400));
		return await d();
	}, p;
};
//#endregion
export { Nt as createTEConnect };


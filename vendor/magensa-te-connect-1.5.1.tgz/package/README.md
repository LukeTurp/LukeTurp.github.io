# TEConnect (Payment)
[![npm version](https://img.shields.io/npm/v/@magensa/te-connect.svg?style=for-the-badge)](https://www.npmjs.com/package/@magensa/te-connect "@magensa/te-connect npm.js")

This package contains shared logic for creating a TEConnect Payment instance in JavaScript applications.

> This package is a Vite library-mode port of the original webpack/babel build.
> The public API (`createTEConnect`) and the shipped TypeScript declarations are
> identical to the prior release.

If you are looking for documentation on TEConnect Payment implementations - please refer to the package of your choice:

- [React](https://github.com/Magensa/te-connect-react)
- [Angular](https://github.com/Magensa/te-connect-ng)
- [JavaScript](https://github.com/Magensa/te-connect-js)

## Installation

```
npm install @magensa/te-connect uuid
```

## Peer Dependencies

| Package | Required version |
|---------|------------------|
| uuid    | >=14.0.0         |

`uuid` is a peer dependency — it is **not** bundled. Most consumers reach this
package transitively through a framework wrapper (`@magensa/te-connect-react`,
`@magensa/te-connect-ng`, `@magensa/te-connect-js`) that provides `uuid`.

## Quick Start

```js
import { createTEConnect } from '@magensa/te-connect';

const teConnect = createTEConnect('__publicKeyGoesHere__');
```

### Non-production frame hosts

By default the secure frame loads from the production host
(`https://svc4.magensa.net/TEConnect`). To target another TEConnect frame
deployment — for example the DEV environment — pass `frameBaseUrl`:

```js
const teConnect = createTEConnect('__devPublicKeyGoesHere__', {
    frameBaseUrl: 'https://teconnectdemo.magensa.dev'
});
```

`frameBaseUrl` must be an `https` URL without a query string or fragment. The
option is honored across manual entry, Payment Request, and 3DS flows.

## Build Outputs

| File                   | Format | Purpose                       |
|------------------------|--------|-------------------------------|
| `dist/te-connect.js`   | ESM    | Bundlers, Vite, Next.js, etc. |
| `dist/te-connect.cjs`  | CJS    | Node.js, webpack 4, Jest      |
| `dist/index.d.ts`      | DTS    | TypeScript declarations       |

> **Migration note:** the original build emitted a single UMD bundle (global
> `te-connect`) with `uuid` bundled in. This port emits dual ESM/CJS and treats
> `uuid` as an externalized peer dependency. Direct `<script>`-tag / CDN
> consumers that relied on the UMD global should consume a bundled framework
> wrapper instead, or build a UMD target explicitly.

## Development

```bash
npm install
npm run build          # Vite build + copy declarations into dist/
npm test               # Vitest unit tests
npm run test:watch     # Watch mode
npm run test:coverage  # Coverage report
npm run typecheck      # Validate declarations + consumer smoke test
npm run verify:externals  # Assert uuid is not bundled into dist/
```

## License

MIT

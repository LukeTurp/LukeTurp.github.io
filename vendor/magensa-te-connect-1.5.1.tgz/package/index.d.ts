// Hand-authored public type declarations for @magensa/te-connect.
//
// Ported from the original library's `te-connect.d.ts`. The original used an
// ambient `declare module "@magensa/te-connect"` block; this port exposes the
// same surface as direct top-level exports so the file works correctly as the
// package's `types` entry (referenced by package.json `types`/`exports`).
//
// Verified against the public API by scripts/dts-consumer-test.ts.

export type RequestClient = {
    instanceId: string,
    requestOrigin: string,
    pubKey: string
};

export type CurrentElements = {
    elements: HTMLIFrameElement,
    formId: string
};

export type CardMetaData = {
    billingZip?: string,
    expirationDate?: string,
    maskedPAN?: string
};

export type ThreeDsStatusResp = "Y" | "A" | "N" | "U" | "C" | "R";

export type ThreeDsResults = {
    scaRequired?: boolean,
    creq?: string,
    status?: ThreeDsStatusResp,
    authenticationValue?: string,
    authenticationType?: string,
    eci?: string,
    acsUrl?: string,
    dsTransId?: string,
    acsTransId?: string,
    sdkTransId?: string,
    error?: string,
    errorDetail?: string,
    errorCode?: string,
    cardholderInfo?: string,
    transactionId?: string,
    correlationId?: string,
    code?: number
};

export type CreatePaymentResponse = {
    code?: string,
    customerTranRef?: string,
    magTranID?: string,
    message?: string,
    timestamp?: string,
    token?: string,
    error?: string,
    status?: number,
    cardMetaData?: null | CardMetaData,
    threedsResults?: ThreeDsResults
};

export type TecPaymentRequestOptions = {
    appleMerchantId?: string,
    googleMerchantId?: string
};

export type TecThreeDsOptions = {
    threedsApiKey: string,
    threedsEnvironment?: "sandbox" | "production"
};

export type CreateTEConnectOptions = {
    hideZip?: boolean,
    tecPaymentRequest?: TecPaymentRequestOptions,
    threeds?: TecThreeDsOptions,
    /**
     * Optional custom frame host, for non-production environments
     * (e.g. "https://teconnectdemo.magensa.dev"). Must be an https URL
     * without query string or fragment. Defaults to the production
     * TEConnect frame.
     */
    frameBaseUrl?: string
};

export type OneOrTwo = "01" | "02";
export type OneThroughFour = "01" | "02" | "03" | "04";
export type OneThroughFive = "01" | "02" | "03" | "04" | "05";
export type AuthenticationIndicator = "01" | "02" | "03" | "04" | "05" | "06";
export type ThreeDsChallengeIndicator = "01" | "02" | "03" | "04" | "05" | "06" | "07" | "08" | "09";

export type ThreeDsAddress = {
    line1?: string,
    line2?: string,
    line3?: string,
    postCode?: string,
    city?: string,
    state?: string,
    country?: string
};

export type ThreeDsMerchantRiskIndicator = {
    shipIndicator?: "01" | "02" | "03" | "04" | "05" | "06" | "07",
    deliveryTimeFrame?: OneThroughFour,
    reorderItemsInd?: OneOrTwo
};

export type ThreeDsAccountInfo = {
    chAccAgeInd?: OneThroughFive,
    chAccDate?: string,
    chAccChangeInd?: OneThroughFour,
    chAccChange?: string,
    chAccPwChangeInd?: OneThroughFive,
    chAccPwChange?: string,
    shipAddressUsageInd?: string,
    txnActivityDay?: string,
    txnActivityYear?: string,
    provisionAttemptsDay?: string,
    nbPurchaseAccount?: string,
    suspiciousAccActivity?: OneOrTwo,
    shipNameIndicator?: string,
    paymentAccInd?: string,
    paymentAccAge?: string
};

export type ThreeDsMsgExt = {
    criticalityIndicator?: boolean,
    data?: any,
    id?: string,
    name: string
};

/**
 * Configure 3DS Instance.
 * TEConnect handles `pan`, `month`, `year`, and `browser`.
 * The remainder options are forwarded to 3DS `authentication` request.
 * [3DS Configuration Options](https://docs.3dsintegrator.com/reference/post_v2-2-authenticate-browser).
 */
export type ThreeDsConfigObj = {
    /**
   * Required for TEConnect to mount challenge node, if necessary.
   */
    challengeNodeId: string,
    amount: number,
    messageCategory?: OneOrTwo,
    challengeIndicator?: ThreeDsChallengeIndicator,
    challengeWindowSize?: OneThroughFive,
    /**
   * Optional value in seconds to prompt a forced timeout for 3DS auth: minimum 1.5;
   * Providing this value will also adjust TEConnect's timeout to create a payment token: minimum 10 (seconds);
   * For example: "2.5" will set 3DS timeout to 2.5 seconds, and TEConnect timeout to 10 seconds.
   * "11" will set 3DS timeout to 11 seconds, and TEConnect timeout to 11 seconds.
   */
    transactionForcedTimeout?: string,
    authenticationInd?: AuthenticationIndicator,
    recurringExpiry?: string,
    recurringFrequency?: string,
    clientTransactionId?: string,
    protocolVersion?: string,
    currency?: string,
    currencyExponent?: number,
    shipping?: ThreeDsAddress,
    billing?: ThreeDsAddress,
    email?: string,
    cardHolderName?: string,
    merchantRiskIndicator?: ThreeDsMerchantRiskIndicator,
    acctInfo?: ThreeDsAccountInfo,
    messageExtension?: ThreeDsMsgExt,
    transType?: "01" | "03" | "10" | "11" | "28",
    threeDSRequestorURL?: string,
    threeDSRequestorDecMaxTime?: string,
    threeDSRequestorDecReqInd?: "Y" | "N",
    purchaseInstalData?: string,
    addrMatch?: string,
    /**
    * @deprecated.
    */
    exponent?: number
};

export type ThreeDsMethods = "GENERATE_JWT" | "AUTHENTICATE_BROWSER" | "FINGERPRINT_DEVICE" | "CHALLENGE";
export type ThreeDsStatus = "REQUESTED" | "SUCCESS" | "FAIL" | "AWAIT_RESULTS";

export type TecThreeDsStatus = {
    threedsMethod: ThreeDsMethods,
    status: ThreeDsStatus,
    message: string
};

export type ThreeDsStatusListener = (event: TecThreeDsStatus) => void;

export interface ThreeDsInterface {
    sendThreedsConfig: (tecElementId: string) => void,
    listenFor: (eventType: string, listener: ThreeDsStatusListener) => void,
    updateThreedsConfig: (threedsConfigObj: ThreeDsConfigObj) => void
}

/** `paymentCredentialStatus` from Apple's `applePayCapabilities()`. */
export type ApplePayPaymentCredentialStatus =
    | "paymentCredentialsAvailable"
    | "paymentCredentialStatusUnknown"
    | "paymentCredentialsUnavailable"
    | "applePayUnsupported";

/** TEConnect-only options read from `applePay.additionalOptions` on the payment request object. */
export type ApplePayAdditionalOptions = {
    /** Show the Apple Pay button whenever `applePayCapabilities()` is available, regardless of credential status. */
    forceButtonDisplay?: boolean,
    /** Credential statuses that should still show the button (by default only available/unknown do). */
    displayButtonWhitelist?: Array<"paymentCredentialsUnavailable" | "applePayUnsupported">
};

export type CanMakePaymentsResult = {
    applePay?: boolean,
    /** Present when the browser supports `applePayCapabilities()`. */
    applePaymentCredentialStatus?: ApplePayPaymentCredentialStatus,
    googlePay?: boolean | { result: boolean, paymentMethodPresent?: boolean }
} | null;

/**
 * Payment Request interface for a single payment request object. Produced by
 * calling `TEConnect.paymentsRequestInterface(paymentRequestObject)`.
 */
export interface TecPaymentRequestInterface {
    createPaymentRequestToken: (instanceDetails: any) => any,
    canMakePayments: () => Promise<CanMakePaymentsResult>,
    listenFor: (eventType: string, listener: (...args: any[]) => any) => void,
    updatePaymentRequest: (paymentRequestObject: any) => void,
    mountGoogleButton: (targetNode: any, instanceDetails: any) => void
}

export type CreateTecPaymentRequestInterface = (paymentRequestObject: any) => TecPaymentRequestInterface;

export interface TEConnect {
    requestClient: RequestClient,
    frameUrl: string,
    createPayment: (elements: CurrentElements, billingZip?: string) => Promise<CreatePaymentResponse>,
    prFrameUrl?: string,
    /**
     * Factory, present only when `tecPaymentRequest` was supplied to
     * `createTEConnect`. Call it with a payment request object to obtain a
     * `TecPaymentRequestInterface`.
     */
    paymentsRequestInterface?: CreateTecPaymentRequestInterface,
    /**
     * Factory, present only when `threeds` was supplied to `createTEConnect`.
     */
    threedsInterface?: (threedsConfigObj: ThreeDsConfigObj) => ThreeDsInterface
}

export function createTEConnect(pubKey: string, teConnectOptions?: CreateTEConnectOptions): TEConnect;
